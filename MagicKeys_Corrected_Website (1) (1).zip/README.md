# MagicKeys — official commercial website

The site on `magickeys.com.au` is based on the approved **MagicKeys Azure Website** package uploaded by RJL. The original cinematic introduction, branding, real customer portal screenshots, interactive 3D gates, optional packages and photographic assets are preserved.

The original website archive remains checked in as `MagicKeys-Azure-Website (1).zip`. `npm run build` extracts its public `dist/` files and replaces **only the Client Access section** with the branded login component in `patches/client-access.html` and `patches/client-access.css`. This keeps the provided design authoritative instead of introducing a different landing page.

## Verify

Run `npm run check` with Node 22+ and `unzip` installed. It builds the public static site and checks that the intro, 3D code, gallery assets and Balwyn login destination remain present. The generated `dist/` folder is a build output and should not be committed.

## Secure sign-in

`#client-access` contains a real direct link to the existing approved **Balwyn High School** portal: `https://magickeys-balwyn-portal.com/login`. The marketing website never asks for portal credentials, handles no access tokens, and issues no hardware control commands. Existing Google, Microsoft and email/password methods stay on the existing portal. Additional clients require their own confirmed portal URLs and access policy before being listed.

Vercel can build this repository using `npm run build` and publish the `dist/` directory. Point the GoDaddy domain DNS to the correct hosting target only after the real website is deployed and verified. Do not change the Balwyn authentication system or controller service as part of publishing this site.
