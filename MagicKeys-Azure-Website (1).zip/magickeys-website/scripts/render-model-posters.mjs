/* Native projections of the same mesh models provide no-JavaScript fallbacks. */
import {writeFile} from 'node:fs/promises';
import '../dist/assets/scene3d.js';
const escape = value => String(value).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');
const paint = (property,value) => {
  const rgba = /^rgba\((\d+),\s*(\d+),\s*(\d+),\s*([.\d]+)\)$/.exec(value);
  return rgba ? ' '+property+'="rgb('+rgba[1]+','+rgba[2]+','+rgba[3]+')" '+property+'-opacity="'+rgba[4]+'"' : ' '+property+'="'+escape(value)+'"';
};
const labels = {single:'single swing gate',double:'double swing gate',sliding:'sliding gate',boom:'boom gate',foyer:'foyer entrance and ceiling detector'};
for (const kind of MagicKeys3D.kinds) {
  for (const state of (kind === 'foyer' ? ['closed','alert'] : ['closed','open'])) {
    const scene = MagicKeys3D.project({kind,state,width:800,height:560});
    const polygons = scene.faces.map(face => '<polygon points="' + face.points.map(p => p.x.toFixed(3)+','+p.y.toFixed(3)).join(' ') + '"' + paint('fill',face.fill) + (face.lineWidth ? paint('stroke',face.stroke) + ' stroke-width="' + face.lineWidth.toFixed(3) + '"' : '') + '/>').join('\n');
    const title = 'Proportioned 3D ' + labels[kind] + ', ' + state;
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="560" viewBox="0 0 800 560" role="img" aria-labelledby="title"><title id="title">' + escape(title) + '</title><desc>Perspective projection of solid mesh hardware with physical thickness, joints and a charcoal platform.</desc><g stroke-linejoin="round">\n' + polygons + '\n</g></svg>\n';
    await writeFile(new URL('../dist/assets/model-'+kind+'-'+state+'.svg',import.meta.url),svg);
  }
}
process.stdout.write('Rendered 10 static projections from the live 3D hardware geometry.\n');
