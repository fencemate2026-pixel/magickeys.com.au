#!/usr/bin/env python3
"""Make genuinely self-contained browser copies; keep source image pixels intact."""
import base64
import json
import mimetypes
import re
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

PROJECT = Path(__file__).resolve().parents[1]
DIST = PROJECT / "dist"
MEDIA_ATTRIBUTE = re.compile(
    r'\s(src|href|poster|data-image|data-preview|data-desktop-src|data-mobile-src)="(assets/[^"<>]+\.(?:png|webp|svg|mp4))"'
)

MEDIA_LOADER = """(() => {
  const payload = document.getElementById('embedded-media');
  const assets = JSON.parse(payload.textContent);
  const videoUrls = {};
  document.querySelectorAll('[data-asset-key]').forEach(element => {
    assets[element.dataset.assetKey] = element.getAttribute('src');
  });
  document.querySelectorAll('[data-asset-poster-key]').forEach(element => {
    assets[element.dataset.assetPosterKey] = element.getAttribute('poster');
  });
  function assetUrl(reference) {
    if (!reference.startsWith('embedded:')) return reference;
    const name = reference.slice(9);
    if (!assets[name]) throw new Error('Missing bundled media: ' + name);
    if (!name.endsWith('.mp4')) return assets[name];
    if (!videoUrls[name]) {
      const encoded = assets[name].split(',')[1];
      const bytes = Uint8Array.from(atob(encoded), character => character.charCodeAt(0));
      videoUrls[name] = URL.createObjectURL(new Blob([bytes], {type:'video/mp4'}));
    }
    return videoUrls[name];
  }
  document.querySelectorAll('[data-image], [data-preview], [data-desktop-src], [data-mobile-src]').forEach(element => {
    for (const key of ['image', 'preview', 'desktopSrc', 'mobileSrc']) {
      if (element.dataset[key]) element.dataset[key] = assetUrl(element.dataset[key]);
    }
  });
  payload.remove();
})();"""


def data_uri(path):
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return "data:" + mime + ";base64," + base64.b64encode(path.read_bytes()).decode()


def portable_page():
    """Images have real inline src attributes, even before any JavaScript runs."""
    page = (DIST / "index.html").read_text()
    scripts = re.findall(r'<script src="(assets/[^"<>]+\.js)" defer></script>', page)
    if not scripts:
        raise ValueError("No application scripts found")
    page = re.sub(r'<script src="assets/[^"<>]+\.js" defer></script>', '', page)
    page = re.sub(r'\s*<link rel="preload"[^>]+>', '', page)
    css = (DIST / "assets/site.css").read_text()
    css = re.sub(r'url\("([^"()]+)"\)', lambda m: 'url("' + data_uri(DIST / "assets" / m[1]) + '")', css)
    page = page.replace('<link rel="stylesheet" href="assets/site.css">', '<style>\n' + css + '\n</style>')
    page = page.replace('href="./"', 'href="#main"')
    direct = set()
    references = set()
    uri_cache = {}

    def uri(name):
        if name not in uri_cache:
            uri_cache[name] = data_uri(DIST / name)
        return uri_cache[name]

    def embed(match):
        attribute, name = match.groups()
        references.add(name)
        if attribute in ('src', 'href', 'poster'):
            direct.add(name)
            key = (' data-asset-key="' + name + '"') if attribute == 'src' else (
                (' data-asset-poster-key="' + name + '"') if attribute == 'poster' else ''
            )
            return ' ' + attribute + '="' + uri(name) + '"' + key
        return ' ' + attribute + '="embedded:' + name + '"'

    page = MEDIA_ATTRIBUTE.sub(embed, page)
    # Dataset references reuse image URLs already present in the document. Only
    # videos or images without an initial visible instance need a JSON payload.
    payload = {name: uri(name) for name in sorted(references - direct)}
    application = '\n'.join((DIST / name).read_text() for name in scripts)
    if '</script' in application.lower():
        raise ValueError("Script content requires closing-tag escaping")
    page = page.replace('</body>',
        '<script type="application/json" id="embedded-media">' + json.dumps(payload, separators=(',', ':')) + '</script>\n'
        + '<script>\n' + MEDIA_LOADER + '\n' + application + '\n</script>\n</body>')
    if re.search(r'\s(?:src|href|poster)="assets/', page):
        raise ValueError("Portable HTML still requests an adjacent asset")
    return page, len(references), scripts


def export(destination):
    destination.mkdir(parents=True, exist_ok=True)
    page, unique_media, scripts = portable_page()
    standalone_path = destination / "MagicKeys-Website.html"
    standalone_path.write_text(page)
    browser_path = destination / "MagicKeys-Open-In-Browser.zip"
    instructions = (
        "MAGICKEYS WEBSITE\n\n"
        "1. Download and extract this ZIP.\n"
        "2. Open MagicKeys.html in Chrome or Edge.\n\n"
        "MagicKeys.html is self-contained. Every image, both transparent logos,\n"
        "the supplied Zing Sans Rust font, the 3D models and intro videos are\n"
        "inside the HTML. You may move that file on its own.\n"
        "No assets folder, installation or web server is needed.\n\n"
        "Use Open / Close to move the 3D gates. Drag a model to rotate the view.\n"
        "Arrow keys rotate a focused model; R or Reset view restores it.\n"
        "The opening video is muted; Skip intro enters the page immediately.\n"
        "Azure publication is separate from opening this local copy.\n"
    )
    with ZipFile(browser_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr("MagicKeys.html", page)
        archive.writestr("START-HERE.txt", instructions)
        archive.write(PROJECT / "licenses/Fontfabric-Free-Font-License.pdf", "licenses/Fontfabric-Free-Font-License.pdf")
    azure_path = destination / "MagicKeys-Azure-Website.zip"
    with ZipFile(azure_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PROJECT.rglob("*")):
            relative = path.relative_to(PROJECT)
            if path.is_file() and not any(part in {".git", "node_modules", "__pycache__"} for part in relative.parts):
                archive.write(path, Path("magickeys-website") / relative)
    for path in (browser_path, azure_path):
        with ZipFile(path) as archive:
            if archive.testzip() is not None:
                raise ValueError("Archive failed integrity check: " + path.name)
    return {
        "html_bytes": len(page.encode()),
        "embedded_unique_media": unique_media,
        "inlined_scripts": scripts,
        "outputs": {path.name: path.stat().st_size for path in (standalone_path, browser_path, azure_path)},
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 scripts/export_website.py /absolute/output/directory")
    output_directory = Path(sys.argv[1]).resolve()
    if output_directory == PROJECT or PROJECT in output_directory.parents:
        raise SystemExit("Output must be outside the source project")
    print(json.dumps(export(output_directory)))
