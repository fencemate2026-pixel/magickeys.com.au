import {readFile,access} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=new URL('../dist/',import.meta.url);
const html=await readFile(new URL('index.html',root),'utf8');
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
if(new Set(ids).size!==ids.length) throw new Error('Duplicate element IDs.');
for(const m of html.matchAll(/\s(?:src|href|poster|data-image|data-preview|data-desktop-src|data-mobile-src)="([^"]+)"/g)){
  const value=m[1];
  if(value.startsWith('#')) {if(!ids.includes(value.slice(1))) throw new Error(`Missing anchor ${value}`);continue;}
  if(/^(?:https?:|data:|tel:)/.test(value)||value==='./') continue;
  await access(new URL(value,root));
}
const css=await readFile(new URL('assets/site.css',root),'utf8');
for(const match of css.matchAll(/url\(["']?([^\s"')]+)["']?\)/g)) await access(new URL(match[1],new URL('assets/',root)));
if(!css.includes('font-family:"Zing Sans Rust"')||!css.includes('zing-sans-rust.otf')) throw new Error('Missing supplied Zing Sans Rust web font.');
for(const script of [...html.matchAll(/<script src="([^"]+)"/g)].map(match=>match[1])){
  const checked=spawnSync(process.execPath,['--check',fileURLToPath(new URL(script,root))],{encoding:'utf8'});
  if(checked.status!==0) throw new Error(checked.stderr);
}
JSON.parse(await readFile(new URL('staticwebapp.config.json',root),'utf8'));
if(!html.includes('https://magickeys.com.au/')) throw new Error('Missing canonical domain.');
if(!html.includes('assets/magickeys-logo.png')) throw new Error('Missing supplied MagicKeys logo.');
process.stdout.write(`Checked ${ids.length} element IDs, local links/assets, JavaScript syntax and Azure static configuration.\n`);
