import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFile, stat } from 'node:fs/promises';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), 'dist');
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.otf':'font/otf','.mp4':'video/mp4','.txt':'text/plain; charset=utf-8','.xml':'application/xml; charset=utf-8'};
const headers = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; connect-src 'none'; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'none'"
};

// This server only delivers the marketing website. It does not provide portal
// authentication, collect credentials, or communicate with gate controllers.
export function createServer() {
  return http.createServer(async (req,res) => {
    const reply=(status,body,type='text/plain; charset=utf-8',extra={})=>{
      res.writeHead(status,{...headers,'Content-Type':type,'Cache-Control':'no-cache',...extra});
      res.end(req.method==='HEAD' ? undefined : body);
    };
    if(!['GET','HEAD'].includes(req.method)) return reply(405,'Method not allowed',undefined,{'Allow':'GET, HEAD'});
    let requested;
    try { requested=decodeURIComponent(new URL(req.url,'http://localhost').pathname); }
    catch { return reply(400,'Invalid request'); }
    if(requested==='/healthz') return reply(200,'ok');
    if(requested==='/login'||requested==='/login/') return reply(302,'',undefined,{'Location':'/#client-access'});
    if(requested==='/'||requested==='/index.html') requested='/index.html';
    if(!/^\/(index\.html|robots\.txt|sitemap\.xml|assets\/[a-zA-Z0-9._-]+)$/.test(requested)) return reply(404,'Page not found');
    const location=path.join(root,requested.slice(1));
    try {
      const info=await stat(location);
      if(!info.isFile()) return reply(404,'Page not found');
      const body=await readFile(location);
      const type=types[path.extname(location)]||'application/octet-stream';
      const extra={'Content-Length':String(body.length)};
      if(path.extname(location)==='.mp4') {
        extra['Accept-Ranges']='bytes';
        if(req.headers.range) {
          const range=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
          if(!range||(!range[1]&&!range[2])) return reply(416,'Range not satisfiable',undefined,{'Content-Range':`bytes */${body.length}`});
          const start=range[1]?Number(range[1]):Math.max(0,body.length-Number(range[2]));
          const end=range[1]?(range[2]?Math.min(Number(range[2]),body.length-1):body.length-1):body.length-1;
          if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=body.length) return reply(416,'Range not satisfiable',undefined,{'Content-Range':`bytes */${body.length}`});
          return reply(206,body.subarray(start,end+1),type,{...extra,'Content-Length':String(end-start+1),'Content-Range':`bytes ${start}-${end}/${body.length}`});
        }
      }
      reply(200,body,type,extra);
    } catch { reply(404,'Page not found'); }
  });
}

if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const port=Number(process.env.PORT||8080);
  createServer().listen(port,'0.0.0.0',()=>process.stdout.write(`MagicKeys marketing website listening on port ${port}\n`));
}
