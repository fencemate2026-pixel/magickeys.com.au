"""Regression checks for downloading or moving the HTML without its assets folder."""
import base64
import importlib.util
import json
import subprocess
import unittest
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('website_export', ROOT / 'scripts/export_website.py')
exporter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exporter)


class Page(HTMLParser):
    def __init__(self, text):
        super().__init__()
        self.elements = []
        self.scripts = {}
        self.current_script = None
        self.feed(text)

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        self.elements.append((tag, attrs))
        if tag == 'script':
            self.current_script = attrs.get('id', 'application')
            self.scripts[self.current_script] = ''

    def handle_data(self, data):
        if self.current_script:
            self.scripts[self.current_script] += data

    def handle_endtag(self, tag):
        if tag == 'script':
            self.current_script = None


class PortableExportTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html, cls.count, cls.script_names = exporter.portable_page()
        cls.page = Page(cls.html)
        cls.source = Page((ROOT / 'dist/index.html').read_text())

    def test_visible_images_are_complete_before_scripts_run(self):
        images = [attrs for tag, attrs in self.page.elements if tag == 'img' and attrs.get('src')]
        source_images = [attrs for tag, attrs in self.source.elements if tag == 'img' and attrs.get('src')]
        self.assertEqual(len(images), len(source_images))
        seen = set()
        for attrs in images:
            with self.subTest(image=attrs.get('data-asset-key')):
                self.assertTrue(attrs['src'].startswith('data:image/'))
                name = attrs['data-asset-key']
                seen.add(name)
                decoded = base64.b64decode(attrs['src'].split(',', 1)[1], validate=True)
                self.assertEqual(decoded, (ROOT / 'dist' / name).read_bytes())
        for name in ['portal-overview.png', 'portal-schedules.png', 'portal-bookings.png',
                     'portal-gate-response.png', 'detection-unit.webp', 'tailgating-example.webp',
                     'campus-concept.png', 'venue-concept.png']:
            self.assertIn('assets/' + name, seen)
        for tag, attrs in self.page.elements:
            for key in ('src', 'href', 'poster'):
                self.assertFalse(attrs.get(key, '').startswith('assets/'), (tag, key))

    def test_tabs_enlargements_and_videos_resolve_without_any_fetch(self):
        # Execute the real portable loader against parsed elements. There are no
        # filesystem/network/browser APIs in this sandbox: all media must resolve
        # from the document itself, just as when the file is moved alone.
        elements = [attrs for _, attrs in self.page.elements if any(
            key in attrs for key in ('data-asset-key', 'data-asset-poster-key', 'data-image',
                                     'data-preview', 'data-desktop-src', 'data-mobile-src'))]
        request = {'elements': elements, 'payload': self.page.scripts['embedded-media'],
                   'loader': exporter.MEDIA_LOADER}
        harness = r"""
const {readFileSync}=require('node:fs');
const vm=require('node:vm');
const input=JSON.parse(readFileSync(0,'utf8'));
const elements=input.elements.map(attrs=>({attrs,dataset:Object.fromEntries(Object.entries(attrs)
  .filter(([key])=>key.startsWith('data-')).map(([key,value])=>[key.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase()),value])),
  getAttribute:key=>attrs[key]}));
let removed=false, blobs=0;
const payload={textContent:input.payload,remove(){removed=true;}};
const document={getElementById(){return payload;},querySelectorAll(selector){
  return elements.filter(element=>selector.split(',').some(part=>part.trim().slice(1,-1) in element.attrs));}};
vm.runInNewContext(input.loader,{document,Uint8Array,atob,Blob,URL:{createObjectURL(blob){
  if(blob.type!=='video/mp4'||blob.size<1000) throw Error('Invalid bundled video');
  return 'blob:embedded/'+(++blobs);}}});
const references=elements.flatMap(element=>['image','preview','desktopSrc','mobileSrc']
  .filter(key=>key in element.dataset).map(key=>({key,value:element.dataset[key]})));
if(!removed||blobs!==2) throw Error('Video payload not fully resolved');
for(const reference of references) {
  if(!reference.value.startsWith(reference.key.endsWith('Src')?'blob:':'data:image/')) throw Error('Unresolved '+reference.key);
}
process.stdout.write(JSON.stringify({references:references.length,blobs}));
"""
        result = subprocess.run(['node', '-e', harness], input=json.dumps(request), text=True,
                                capture_output=True, check=True)
        facts = json.loads(result.stdout)
        self.assertGreater(facts['references'], 20)
        self.assertEqual(facts['blobs'], 2)

    def test_physical_models_and_every_script_are_in_the_same_html(self):
        self.assertEqual(self.script_names, ['assets/scene3d.js', 'assets/scene3d-mounts.js', 'assets/site.js'])
        application = self.page.scripts['application']
        for name in self.script_names:
            self.assertIn((ROOT / 'dist' / name).read_text(), application)
        result = subprocess.run(['node', '--check', '-'], input=application, text=True,
                                capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        kinds = {attrs['data-scene-kind'] for _, attrs in self.page.elements if 'data-scene-kind' in attrs}
        self.assertEqual(kinds, {'single', 'double', 'boom'})
        model_choices = {attrs['data-demo'] for _, attrs in self.page.elements if 'data-demo' in attrs}
        self.assertEqual(model_choices, {'single', 'swing', 'sliding', 'boom', 'foyer'})


if __name__ == '__main__':
    unittest.main()
