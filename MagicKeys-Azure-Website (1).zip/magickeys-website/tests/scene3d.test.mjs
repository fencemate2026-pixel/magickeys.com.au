import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../dist/assets/scene3d.js', import.meta.url), 'utf8');
const sandbox = {};
vm.runInNewContext(source, sandbox);
const scene = sandbox.MagicKeys3D;
const near = (actual, expected, tolerance = 1e-8) => assert.ok(Math.abs(actual - expected) < tolerance, `${actual} is not near ${expected}`);
const extent = (vertices, axis) => Math.max(...vertices.map(v => v[axis])) - Math.min(...vertices.map(v => v[axis]));

test('the 3D module loads without a DOM and supplies solid closed steel leaf meshes', () => {
  assert.equal(typeof scene.create, 'function');
  assert.equal(typeof scene.project, 'function');
  const model = scene.buildModel({kind: 'single', state: 'closed'});
  const topRail = model.meshes.find(m => m.id === 'left-leaf-top-rail');
  const picket = model.meshes.find(m => m.role === 'picket');
  assert.equal(topRail.vertices.length, 8);
  assert.equal(topRail.faces.length, 6);
  assert.ok(extent(topRail.vertices, 'x') > .9);
  near(extent(topRail.vertices, 'y'), .049);
  near(extent(topRail.vertices, 'z'), .061);
  near(extent(picket.vertices, 'x'), .018);
  near(extent(picket.vertices, 'z'), .026);
  assert.ok(model.meshes.some(m => m.role === 'operator'));
  assert.ok(model.meshes.some(m => m.id.includes('-bolt-')));
});

test('representative gate opening and height proportions match the documented scene scales', () => {
  const single = scene.buildModel({kind: 'single'}).metadata.dimensions;
  const double = scene.buildModel({kind: 'double'}).metadata.dimensions;
  const sliding = scene.buildModel({kind: 'sliding'}).metadata.dimensions;
  const boom = scene.buildModel({kind: 'boom'}).metadata.dimensions;
  near(single.openingWidth, 1.2); near(single.leafHeight, 1.8);
  near(double.openingWidth, 3.6); near(double.leafHeight, 1.8);
  near(sliding.openingWidth, 4.4); near(sliding.leafHeight, 1.8);
  near(boom.armLength, 4.5); near(boom.pivotHeight, 1.05);
  assert.ok(boom.armDepth < boom.armLength / 40);
  assert.ok(sliding.travel > sliding.openingWidth);
});

test('swing leaves rotate about stationary physical hinge axes with opposite double-leaf motion', () => {
  for (const kind of ['single', 'double']) {
    const closed = scene.buildModel({kind, state: 'closed'}).metadata;
    const open = scene.buildModel({kind, state: 'open'}).metadata;
    assert.equal(open.hinges.length, kind === 'single' ? 1 : 2);
    for (let i = 0; i < open.hinges.length; i++) {
      const a = closed.hinges[i].position, b = open.hinges[i].position;
      near(a.x, b.x); near(a.y, b.y); near(a.z, b.z);
      const leaf = open.movingParts[i];
      near(leaf.tip.x, b.x);
      near(leaf.tip.z, -leaf.width);
      near(Math.hypot(leaf.tip.x - b.x, leaf.tip.z - b.z), closed.movingParts[i].width);
    }
    near(open.hinges[0].angle, Math.PI / 2);
    if (kind === 'double') {
      near(open.hinges[1].angle, -Math.PI / 2);
      assert.ok(closed.movingParts[0].tip.x < closed.movingParts[1].tip.x, 'closed leaves retain a small meeting clearance');
    }
  }
});

test('sliding gate translates its complete leaf while the guide posts and motor remain fixed', () => {
  const closed = scene.buildModel({kind: 'sliding', state: 'closed'});
  const open = scene.buildModel({kind: 'sliding', state: 'open'});
  const travel = closed.metadata.dimensions.travel;
  const closedLeaf = closed.meshes.find(m => m.id === 'sliding-leaf-hinge-stile');
  const openLeaf = open.meshes.find(m => m.id === 'sliding-leaf-hinge-stile');
  for (let i = 0; i < closedLeaf.vertices.length; i++) {
    near(openLeaf.vertices[i].x - closedLeaf.vertices[i].x, -travel);
    near(openLeaf.vertices[i].y, closedLeaf.vertices[i].y);
    near(openLeaf.vertices[i].z, closedLeaf.vertices[i].z);
  }
  for (const id of ['guide-post', 'latch-post', 'motor-case']) {
    assert.deepEqual(open.meshes.find(m => m.id === id).vertices, closed.meshes.find(m => m.id === id).vertices);
  }
});

test('boom rotation preserves arm length and raises the far end from the pedestal pivot', () => {
  const closed = scene.buildModel({kind: 'boom', state: 'closed'}).metadata;
  const open = scene.buildModel({kind: 'boom', state: 'open'}).metadata;
  const a = closed.movingParts[0], b = open.movingParts[0];
  near(a.tip.y, a.pivot.y);
  near(a.tip.x - a.pivot.x, 4.5);
  assert.ok(b.tip.y > 5.45);
  assert.ok(Math.abs(b.tip.x - b.pivot.x) < .45);
  near(Math.hypot(b.tip.x - b.pivot.x, b.tip.y - b.pivot.y), 4.5);
  near(open.hinges[0].position.y, closed.hinges[0].position.y);
});

test('foyer includes two translated sliding leaves, a ceiling sensor and ordinary-height people', () => {
  const closed = scene.buildModel({kind: 'foyer', state: 'closed'});
  const open = scene.buildModel({kind: 'foyer', state: 'open'});
  const alert = scene.buildModel({kind: 'foyer', state: 'alert'});
  assert.equal(closed.metadata.personCount, 1);
  assert.equal(alert.metadata.personCount, 2);
  assert.ok(alert.meshes.some(m => m.role === 'ceiling-detector'));
  near(alert.metadata.dimensions.representativePersonHeight, 1.70);
  assert.ok(open.metadata.movingParts[0].translation < 0);
  assert.ok(open.metadata.movingParts[1].translation > 0);
  near(Math.abs(open.metadata.movingParts[0].translation), Math.abs(open.metadata.movingParts[1].translation));
  const sensor = alert.meshes.find(m => m.role === 'ceiling-detector');
  assert.ok(Math.min(...sensor.vertices.map(v => v.y)) > 2.5);
});

test('perspective fits real meshes in every operating pose and full orbit, including narrow stages', () => {
  for (const kind of scene.kinds) for (const state of ['closed', 'open', 'alert']) {
    for (const [width, height] of [[180, 180], [180, 280], [640, 260]]) {
      for (const yaw of [-Math.PI, -1.2, 0, .58, 1.8, Math.PI]) for (const pitch of [.07, .28, .76]) {
        const result = scene.project({kind, state, yaw, pitch, width, height});
        assert.ok(result.faces.length > 15);
        for (const face of result.faces) {
          assert.ok(face.points.length >= 3);
          assert.ok(Number.isFinite(face.depth) && face.depth > 0);
          for (const p of face.points) {
            assert.ok(p.x > 0 && p.x < width, `${kind} ${state} x=${p.x} outside ${width}`);
            assert.ok(p.y > 0 && p.y < height, `${kind} ${state} y=${p.y} outside ${height}`);
          }
        }
        assert.ok(result.faces.some(face => Math.abs(face.normal?.x || 0) > .5), 'a true side face is projected');
      }
    }
  }
});

test('swept intermediate poses stay fitted and alter geometry rather than stretching a flat image', () => {
  for (const kind of scene.kinds) for (const progress of [.1, .35, .6, .9]) {
    const result = scene.project({kind, state: 'open', progress, width: 180, height: 180});
    const b = result.metadata.projectedBounds;
    assert.ok(b.minX > 0 && b.maxX < 180 && b.minY > 0 && b.maxY < 180);
    assert.ok(result.metadata.bounds.max.z > result.metadata.bounds.min.z);
  }
  assert.throws(() => scene.buildModel({kind: 'invented'}), /Unknown/);
  assert.throws(() => scene.buildModel({state: 'invented'}), /Unknown/);
});

function mountedScene({reduced = false} = {}) {
  let nextFrame = 0, clearCount = 0, intersection;
  const frames = new Map();
  const emitter = extra => {
    const listeners = new Map();
    return {
      ...extra,
      addEventListener(name, handler) { if (!listeners.has(name)) listeners.set(name, new Set()); listeners.get(name).add(handler); },
      removeEventListener(name, handler) { listeners.get(name)?.delete(handler); },
      emit(name, value = {}) { for (const handler of listeners.get(name) || []) handler(value); }
    };
  };
  const document = emitter({hidden: false});
  const media = emitter({matches: reduced});
  const attributes = new Map();
  const canvas = emitter({
    style: {}, ownerDocument: document, width: 0, height: 0,
    getContext() { return {setTransform() {}, clearRect() { clearCount++; }, beginPath() {}, moveTo() {}, lineTo() {}, closePath() {}, fill() {}, stroke() {}}; },
    getBoundingClientRect() { return {width: 180, height: 180}; },
    getAttribute(name) { return attributes.get(name); }, hasAttribute(name) { return attributes.has(name); }, setAttribute(name, value) { attributes.set(name, value); },
    focus() {}, setPointerCapture() {}
  });
  const browser = {
    document, matchMedia: () => media, devicePixelRatio: 1,
    requestAnimationFrame: callback => { const id = ++nextFrame; frames.set(id, callback); return id; },
    cancelAnimationFrame: id => frames.delete(id),
    ResizeObserver: class { observe() {} disconnect() {} },
    IntersectionObserver: class { constructor(handler) { intersection = handler; } observe() {} disconnect() {} }
  };
  vm.runInNewContext(source, browser);
  const mounted = browser.MagicKeys3D.create(canvas, {kind: 'double'});
  function flush(time) { for (const [id, callback] of [...frames]) { frames.delete(id); callback(time); } }
  return {mounted, canvas, document, frames, flush, setIntersection: visible => intersection([{isIntersecting: visible}]), get clearCount() { return clearCount; }};
}

test('hidden scenes stop rendering and settled scenes do not run an idle animation loop', () => {
  const page = mountedScene();
  page.flush(0);
  assert.equal(page.frames.size, 0);
  page.mounted.setState('open');
  page.flush(100); page.flush(400);
  assert.ok(page.mounted.getView().progress > 0 && page.mounted.getView().progress < 1);
  page.setIntersection(false);
  assert.equal(page.frames.size, 0);
  const count = page.clearCount;
  page.mounted.setState('closed'); page.flush(900);
  assert.equal(page.clearCount, count);
  near(page.mounted.getView().progress, 0);
  page.setIntersection(true); page.flush(1000);
  assert.equal(page.frames.size, 0);
  assert.ok(page.clearCount > count);
  page.mounted.destroy();
  page.mounted.setState('open');
  assert.equal(page.frames.size, 0);
});

test('reduced-motion actions settle immediately and keyboard orbit/reset remains usable', () => {
  const page = mountedScene({reduced: true});
  page.flush(0);
  page.mounted.setState('open');
  near(page.mounted.getView().progress, 1);
  page.flush(1000);
  assert.equal(page.frames.size, 0);
  page.canvas.emit('keydown', {key: 'ArrowRight', preventDefault() {}});
  assert.ok(page.mounted.getView().yaw > scene.defaultView.yaw);
  page.canvas.emit('keydown', {key: 'R', preventDefault() {}});
  near(page.mounted.getView().yaw, scene.defaultView.yaw);
  page.mounted.destroy();
  assert.equal(page.frames.size, 0);
});
