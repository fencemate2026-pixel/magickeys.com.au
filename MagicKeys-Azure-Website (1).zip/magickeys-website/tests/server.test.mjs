import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from '../server.mjs';
import http from 'node:http';

test('marketing server exposes public content, redirects login to the client section and never exposes source files',async t=>{
  const server=createServer();
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const address=`http://127.0.0.1:${server.address().port}`;
  const home=await fetch(address);
  assert.equal(home.status,200);
  assert.match(home.headers.get('content-type'),/text\/html/);
  assert.match(await home.text(),/MagicKeys/);
  const login=await fetch(address+'/login',{redirect:'manual'});
  assert.equal(login.status,302);
  assert.equal(login.headers.get('location'),'/#client-access');
  for(const file of ['/server.mjs','/package.json','/.env','/api/gates','/assets/..%2f..%2fpackage.json']) {
    const result=await fetch(address+file);
    assert.equal(result.status,404,file);
  }
  const head=await fetch(address+'/assets/magickeys-logo.png',{method:'HEAD'});
  assert.equal(head.status,200);
  assert.equal(head.headers.get('content-type'),'image/png');
  assert.equal(await head.text(),'');
  assert.match(head.headers.get('content-security-policy'),/connect-src 'none'/);
  const font=await fetch(address+'/assets/zing-sans-rust.otf');
  assert.equal(font.status,200);
  assert.equal(font.headers.get('content-type'),'font/otf');
  const fontBytes=Buffer.from(await font.arrayBuffer());
  assert.equal(fontBytes.subarray(0,4).toString('ascii'),'OTTO');
  const movie=await fetch(address+'/assets/magickeys-intro.mp4',{headers:{Range:'bytes=0-31'}});
  assert.equal(movie.status,206);
  assert.equal(movie.headers.get('content-type'),'video/mp4');
  assert.equal(movie.headers.get('accept-ranges'),'bytes');
  assert.match(movie.headers.get('content-range'),/^bytes 0-31\/\d+$/);
  const movieBytes=Buffer.from(await movie.arrayBuffer());
  assert.equal(movieBytes.length,32);
  assert.equal(movieBytes.subarray(4,8).toString('ascii'),'ftyp');
  const badRange=await fetch(address+'/assets/magickeys-intro.mp4',{headers:{Range:'bytes=999999999-'}});
  assert.equal(badRange.status,416);
  const post=await fetch(address,{method:'POST'});
  assert.equal(post.status,405);
  assert.equal(post.headers.get('allow'),'GET, HEAD');
  // A literal path bypasses fetch's URL normalization and checks malformed input.
  const malformed=await new Promise(resolve=>http.get(address+'/%zz',res=>{res.resume();resolve(res.statusCode)}));
  assert.equal(malformed,400);
});
