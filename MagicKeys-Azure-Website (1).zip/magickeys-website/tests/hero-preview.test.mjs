import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const source=await readFile(new URL('../dist/assets/site.js',import.meta.url),'utf8');
const previewSource=source.slice(source.indexOf('// Hero portal preview.'));

function previewPage({reduced=false,introActive=false}={}) {
  let now=0;let nextId=0;
  const timers=new Map();
  function element(id) {
    const classes=new Set();const listeners={};const attributes={};
    return {id,dataset:{},style:{},disabled:false,textContent:'',
      classList:{add:name=>classes.add(name),remove:name=>classes.delete(name),contains:name=>classes.has(name)},
      addEventListener(name,listener){listeners[name]=listener;},
      emit(name){listeners[name]?.();},click(){if(!this.disabled)this.emit('click');},
      setAttribute(name,value){attributes[name]=value;},getAttribute(name){return attributes[name];},
      getBoundingClientRect(){return {left:10,top:id==='hero-gate-close'?100:50,width:62,height:34};}
    };
  }
  const ids=['hero-preview','hero-preview-workspace','hero-gate-stage','hero-gate-state','hero-gate-open','hero-gate-close','hero-preview-toggle','hero-preview-cursor'];
  const elements=Object.fromEntries(ids.map(id=>[id,element(id)]));
  elements['hero-gate-stage'].dataset.state='closed';
  elements['hero-gate-state'].textContent='CLOSED';
  elements['hero-gate-close'].disabled=true;
  const body=element('body');
  if(introActive)body.classList.add('intro-active');
  const document=element('document');document.body=body;document.hidden=false;
  const context={document,window:{},reducedMotion:{matches:reduced,addEventListener(){}},
    $:selector=>elements[selector.slice(1)]??null,
    setTimeout:(callback,delay)=>{const id=++nextId;timers.set(id,{callback,at:now+delay});return id;},
    clearTimeout:id=>timers.delete(id)};
  vm.runInNewContext(previewSource,context);
  function advance(milliseconds) {
    const end=now+milliseconds;
    for(;;) {
      const next=[...timers].filter(([,timer])=>timer.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];
      if(!next)break;
      now=next[1].at;timers.delete(next[0]);next[1].callback();
    }
    now=end;
  }
  return {elements,body,document,advance,timers};
}

test('hero cursor waits for the intro, then opens and closes the portal gate preview',()=>{
  const p=previewPage({introActive:true});
  p.advance(5000);
  assert.equal(p.elements['hero-gate-stage'].dataset.state,'closed');
  assert.equal(p.elements['hero-preview'].classList.contains('is-auto'),false);
  p.body.classList.remove('intro-active');
  p.advance(1500);
  assert.equal(p.elements['hero-gate-stage'].dataset.state,'open');
  assert.equal(p.elements['hero-gate-open'].disabled,true);
  p.advance(1500);
  assert.equal(p.elements['hero-gate-state'].textContent,'OPEN');
  p.advance(3000);
  assert.equal(p.elements['hero-gate-stage'].dataset.state,'closed');
  p.advance(1200);
  assert.equal(p.elements['hero-gate-state'].textContent,'CLOSED');
});

test('Pause and manual controls stop the cursor from overriding the chosen gate state',()=>{
  const p=previewPage();
  p.advance(2000);
  p.elements['hero-preview-toggle'].click();
  p.advance(15000);
  assert.equal(p.elements['hero-gate-state'].textContent,'OPEN');
  assert.equal(p.elements['hero-preview-toggle'].textContent,'Replay preview');
  assert.equal(p.elements['hero-preview'].classList.contains('is-auto'),false);
  p.elements['hero-gate-close'].click();
  p.advance(15000);
  assert.equal(p.elements['hero-gate-state'].textContent,'CLOSED');
  assert.equal(p.timers.size,0);
  p.elements['hero-preview-toggle'].click();
  p.advance(2000);
  assert.equal(p.elements['hero-gate-state'].textContent,'OPEN');
  p.document.hidden=true;p.document.emit('visibilitychange');
  p.advance(10000);
  assert.equal(p.elements['hero-gate-stage'].dataset.state,'open');
});

test('reduced motion keeps automatic playback off and manual controls respond immediately',()=>{
  const p=previewPage({reduced:true});
  p.advance(15000);
  assert.equal(p.elements['hero-gate-state'].textContent,'CLOSED');
  assert.equal(p.timers.size,0);
  assert.equal(p.elements['hero-preview-toggle'].textContent,'Toggle preview gate');
  p.elements['hero-gate-open'].click();
  assert.equal(p.elements['hero-gate-state'].textContent,'OPEN');
  p.elements['hero-gate-close'].click();
  assert.equal(p.elements['hero-gate-state'].textContent,'CLOSED');
  assert.equal(p.timers.size,0);
});
