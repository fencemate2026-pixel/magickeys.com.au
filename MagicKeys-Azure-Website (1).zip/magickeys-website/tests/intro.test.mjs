import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const source=await readFile(new URL('../dist/assets/site.js',import.meta.url),'utf8');
function page({reduced=false,mobile=false,blocked=false}={}) {
  const timers=new Map();let timerId=0;let document;
  function element(id) {
    const listeners={};const classes=new Set();
    return {id,hidden:false,inert:false,isConnected:true,dataset:{},
      classList:{add:name=>classes.add(name),remove:name=>classes.delete(name),contains:name=>classes.has(name)},
      addEventListener(name,fn){listeners[name]=fn;},emit(name,event={}){listeners[name]?.(event);},
      focus(){document.activeElement=this;},getAttribute(name){return this[name]??null;},
      querySelectorAll(){return[];}
    };
  }
  const body=element('body');const main=element('main');
  const header=element('header');const footer=element('footer');const intro=element('site-intro');
  intro.hidden=true;
  const video=element('intro-video');
  video.dataset={desktopSrc:'assets/magickeys-intro.mp4',mobileSrc:'assets/magickeys-intro-mobile.mp4'};
  video.play=()=>{video.playCount=(video.playCount||0)+1;return blocked?Promise.reject(new Error('Autoplay blocked')):Promise.resolve();};
  video.pause=()=>{video.paused=true;};video.load=()=>{};
  const skip=element('intro-skip');const replay=element('intro-replay');const play=element('intro-play');play.hidden=true;
  intro.querySelectorAll=()=>[skip,play];
  const ids=Object.fromEntries([main,intro,video,skip,replay,play].map(e=>['#'+e.id,e]));
  document={body,activeElement:body,querySelector:selector=>ids[selector]??null,
    querySelectorAll:selector=>selector.startsWith('.site-header')?[header,main,footer]:[],addEventListener(){}};
  const window={matchMedia:query=>({matches:query.includes('prefers-reduced-motion')?reduced:query.includes('max-width')?mobile:false})};
  vm.runInNewContext(source,{document,window,setTimeout:(fn,ms)=>{const id=++timerId;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id)});
  const runTimer=ms=>{for(const [id,timer] of [...timers]) if(timer.ms===ms){timers.delete(id);timer.fn();}};
  return {document,body,main,header,footer,intro,video,skip,replay,play,runTimer};
}

test('opening video plays muted and returns focus and page access when it ends',()=>{
  const p=page();
  assert.equal(p.intro.hidden,false);
  assert.equal(p.video.muted,true);
  assert.equal(p.video.src,'assets/magickeys-intro.mp4');
  assert.equal(p.video.playCount,1);
  assert.equal(p.main.inert,true);
  assert.equal(p.document.activeElement,p.skip);
  p.video.emit('ended');p.runTimer(550);
  assert.equal(p.intro.hidden,true);
  assert.equal(p.main.inert,false);
  assert.equal(p.header.inert,false);
  assert.equal(p.footer.inert,false);
  assert.equal(p.document.activeElement,p.main);
});

test('blocked autoplay offers Play, chooses the mobile clip and keeps Skip working',async()=>{
  const p=page({blocked:true,mobile:true});await Promise.resolve();
  assert.equal(p.video.src,'assets/magickeys-intro-mobile.mp4');
  assert.equal(p.play.hidden,false);
  p.skip.emit('click');p.runTimer(550);
  assert.equal(p.intro.hidden,true);
  assert.equal(p.main.inert,false);
});

test('reduced motion opens the site directly and an intro timeout cannot trap the page',()=>{
  const reduced=page({reduced:true});
  assert.equal(reduced.intro.hidden,true);
  assert.equal(reduced.video.playCount,undefined);
  assert.equal(reduced.main.inert,false);
  const slow=page();slow.runTimer(14000);slow.runTimer(550);
  assert.equal(slow.intro.hidden,true);
  assert.equal(slow.main.inert,false);
});
