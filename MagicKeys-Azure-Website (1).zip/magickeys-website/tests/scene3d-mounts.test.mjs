import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const source = await readFile(new URL('../dist/assets/scene3d-mounts.js',import.meta.url),'utf8');
function fixture({canvasBlocked=false}={}) {
  const canvas={hidden:true,attributes:{},setAttribute(key,value){this.attributes[key]=value;}};
  const poster={hidden:false,src:'data:image/svg+xml;closed',alt:''};
  const stage={id:'gate-stage',dataset:{sceneKind:'double',state:'closed'},classList:{add(){}},
    querySelector(selector){return selector==='canvas'?canvas:poster;}};
  const image=(kind,state)=>({dataset:{modelPoster:kind+':'+state},getAttribute(){return 'data:image/svg+xml;'+kind+'-'+state;}});
  const posters=['single','double','sliding','boom','foyer'].flatMap(kind=>['closed','open','alert'].map(state=>image(kind,state)));
  const handlers={};const reset={dataset:{resetModel:'gate-stage'},addEventListener(name,handler){handlers[name]=handler;}};
  const commands=[];
  const model={setKind(kind){commands.push(['kind',kind]);},setState(state,options){commands.push(['state',state,options.animate]);},resetView(){commands.push(['reset']);}};
  const sandbox={document:{querySelectorAll(selector){return selector==='[data-model-poster]'?posters:selector==='[data-scene-kind]'?[stage]:[reset];}},MagicKeys3D:{create(element,options){
    assert.equal(element.hidden,false,'Canvas must have layout dimensions before create()');
    assert.equal(options.kind,'double');
    if(canvasBlocked) throw Error('Canvas unavailable');
    return model;
  }}};
  vm.runInNewContext(source,sandbox);
  return {canvas,poster,stage,reset,handlers,commands,api:sandbox.MagicKeysViews};
}
test('mounting reveals a real 3D canvas and routes gate choice, state and reset',()=>{
  const f=fixture();assert.equal(f.canvas.hidden,false);assert.equal(f.poster.hidden,true);assert.equal(f.reset.disabled,false);
  f.api.update('gate-stage',{kind:'sliding',state:'open'});
  assert.deepEqual(f.commands.slice(-2),[['kind','sliding'],['state','open',false]]);
  assert.equal(f.stage.dataset.sceneKind,'sliding');assert.match(f.canvas.attributes['aria-label'],/sliding gate, open/);
  f.api.update('gate-stage',{state:'closed'});
  assert.deepEqual(f.commands.at(-1),['state','closed',true]);
  f.handlers.click();assert.deepEqual(f.commands.at(-1),['reset']);
});
test('a blocked canvas keeps visible matching 3D posters for every chosen gate state',()=>{
  const f=fixture({canvasBlocked:true});assert.equal(f.canvas.hidden,true);assert.equal(f.poster.hidden,false);assert.equal(f.reset.disabled,true);
  f.api.update('gate-stage',{kind:'boom',state:'open'});
  assert.equal(f.poster.src,'data:image/svg+xml;boom-open');assert.match(f.poster.alt,/boom gate, open/);
  f.api.update('gate-stage',{kind:'foyer',state:'alert'});
  assert.equal(f.poster.src,'data:image/svg+xml;foyer-alert');assert.match(f.poster.alt,/two people detected/);
});
