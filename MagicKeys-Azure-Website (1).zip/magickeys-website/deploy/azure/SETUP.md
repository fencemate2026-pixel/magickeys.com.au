# Azure setup for magickeys.com.au

This is the **advertising website**. Keep the existing MagicKeys portal and its authentication as separate infrastructure.

## Option A — Azure Static Web Apps

Use this for the static marketing website. Deploy the `dist` directory; there is no build or API directory.

1. Select or create the Azure Static Web App intended for the advertising website.
2. Connect its GitHub repository and production branch. The included `.github/workflows/azure-static-web-apps.yml` uses the GitHub repository/environment secret `AZURE_STATIC_WEB_APPS_API_TOKEN`, obtained from that specific Azure Static Web App. Do not paste it into chat or commit it.
3. Run the workflow and verify the returned Azure hostname before changing DNS.
4. Add `magickeys.com.au` and `www.magickeys.com.au` under **Custom domains** in the selected Azure resource. Use the exact validation records Azure provides.
5. For the apex domain, use the DNS provider's ALIAS/ANAME/CNAME flattening support, or an Azure DNS alias. Set `www` to the exact Azure hostname using a CNAME. Do not guess an Azure hostname, IP or validation token.
6. Confirm HTTPS works at the domain, then configure the preferred canonical/default domain through Azure.

Microsoft references:
- https://learn.microsoft.com/en-us/azure/static-web-apps/build-configuration
- https://learn.microsoft.com/en-us/azure/static-web-apps/apex-domain-external
- https://learn.microsoft.com/en-us/azure/static-web-apps/custom-domain

## Option B — Azure App Service

If you already have a dedicated App Service for this marketing website, use the included dependency-free Node server.

1. Configure the app for the supported Node.js 22 Linux runtime, HTTPS only and startup command `node server.mjs`.
2. Copy `deploy/azure/appservice-deploy.yml` into `.github/workflows/` and disable/remove the Static Web Apps workflow so only the chosen host receives deployments.
3. Configure GitHub OIDC federation and its `production` environment for the selected app. Set the environment secrets `AZURE_CLIENT_ID`, `AZURE_TENANT_ID` and `AZURE_SUBSCRIPTION_ID`, and variable `AZURE_APP_NAME`.
4. Run the workflow. It deploys only `dist`, `server.mjs` and `package.json`.
5. Verify the marketing pages, logo assets and `/healthz` on the Azure hostname.
6. Add the custom-domain bindings and managed certificates in App Service using the exact ownership-validation and DNS records Azure displays.

Microsoft references:
- https://learn.microsoft.com/en-us/azure/app-service/deploy-github-actions
- https://learn.microsoft.com/en-us/azure/app-service/app-service-web-tutorial-custom-domain

## Existing portal

The Client Login navigation opens the advertising site's client-access section. Set its outgoing portal link with `scripts/set-portal.mjs` after confirming the real main portal address. No authentication settings on the existing portal need changing for a normal link.

## Required before go-live

- The selected Azure marketing-site resource and access to its deployment path.
- The existing main portal URL for the optional outgoing client login link.
- Domain-management access to apply the Azure-provided DNS records.
- Live desktop/mobile checks after Azure deployment.

These are setup requirements, not changes already made.
