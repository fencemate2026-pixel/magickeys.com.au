# MagicKeys advertising website

An independent product website for **magickeys.com.au**, using the supplied MagicKeys artwork with a transparent background and the supplied Zing Sans Rust font.

The existing operational portal is separate. This project advertises MagicKeys; it does not implement account authentication or talk to physical gate controllers.

## What is included

- A product-led design with a cinematic sapphire hero, large real software previews, bright editorial sections, orange headings and responsive layouts.
- An 8.8-second silent AI face assembly followed by the official MagicKeys logo, with automatic opening playback, Skip and Replay controls.
- Separate 1080p landscape and portrait intros for desktop and mobile.
- Prominent MagicKeys and RJL branding placed directly on light page surfaces in the header, provenance strip and footer, without logo panels.
- Product introduction, platform capabilities and site-type sections.
- Two labelled AI-generated customisation concepts for a school campus and a shared venue, with full-size enlargement.
- A gallery of real portal screens covering overview, gate schedules, venue bookings and gate response feedback.
- A full 13-image scrollable gallery, including the supplied activity record, emergency confirmation dialogs, package visuals and detection equipment.
- An animated hero preview matching the portal’s green Open and red Close controls for a single swing gate, with a moving cursor, manual controls and Pause/Replay.
- Optional Sentinel CCTV and Emergency Guidance sections, including illustrative projector and staff-review screens.
- Solid 3D mesh models for single swing, double swing, sliding and boom gates, plus sliding foyer doors with a ceiling-mounted detector. Gates move about actual hinges or along their tracks, with mouse/touch orbit, keyboard controls and reset. Static projections of the same geometry remain visible when canvas or JavaScript is unavailable.
- Supplied detection-unit and tailgating images in MagicKeys Detect, with keyboard-accessible enlargement.
- Client-access section to connect to the existing portal.
- Direct team contact links (0400 101 132), RJL Commercial website links, FAQs, privacy information, responsive navigation and keyboard controls.
- Accessible screenshot enlargement and keyboard-operated image galleries.
- Azure Static Web Apps configuration and an optional Azure App Service Node server.
- Canonical domain, sitemap and robots.txt.

## Open a downloaded copy

Download **MagicKeys-Website.html** and open it in Chrome or Edge. Every visible image has an embedded `src`, so photos and screenshots appear even before JavaScript runs. The supplied Zing Sans Rust font, transparent logos, intro videos and 3D model code are also embedded. No assets folder, installation or server is needed.

**MagicKeys-Open-In-Browser.zip** contains the exact same self-contained page as **MagicKeys.html**, plus opening instructions and the font licence. Extract the ZIP, then open the HTML. That HTML may be moved on its own without losing its pictures.

On the interactive demo, choose a gate type and use Open / Close. Drag a model to rotate it; a focused model also supports the arrow keys and R or Home to reset. Reduced-motion preferences make state changes immediate. Models are illustrative, based on the supplied portal’s galvanized vertical-bar gate style, rather than construction drawings of a specific installation.

To regenerate all three deliverables with Python 3:

```sh
python3 scripts/export_website.py /absolute/output/directory
```

## Existing portal link

The main portal URL was not supplied in this session. The navigation currently leads to the client-access section, where RJL Commercial can provide a client's assigned portal link. It does not route all clients into the school-specific Balwyn portal.

When the correct existing portal URL is known, connect it with:

```sh
node scripts/set-portal.mjs https://YOUR-EXISTING-PORTAL/login
npm run check
```

This changes the client section's call to action to **Open client portal**. The marketing navigation continues to lead to that section.

## Local checks

Requires Node.js 22 or later. No installation or external dependencies are required.

```sh
npm run check
npm test
```

The portable-export checks require Python 3. Regenerate no-JavaScript model posters after geometry changes with `node scripts/render-model-posters.mjs`.

For local use outside the managed preview environment, `npm start` serves the website on port 8080, or the `PORT` environment setting.

## Azure deployment

See [deploy/azure/SETUP.md](deploy/azure/SETUP.md). Azure deployment and custom-domain activation have not been performed: this session has no Azure hosting connection. The Azure deployment job needs the selected Azure resource and deployment credentials or a configured GitHub OIDC identity.

## Opening animation

The intro is a brand animation, not a live loading or hardware connection screen. It plays muted, supports Skip and Replay, and automatically returns to the page after playback or a timeout. Reduced-motion preferences bypass automatic playback. `creative/render_intro.py` renders the local motion graphic from the generated face and supplied logo, using Python 3, Pillow, NumPy and FFmpeg. These are authoring tools only; the deployed site has no Python runtime dependency.

## Brand assets

`dist/assets/magickeys-logo.png` is a transparent-background image edit of the supplied official artwork. Both supplied logos have true alpha transparency and sit directly on the page background. No filled logo wrapper, frame, border or glass plate is used. Light page surfaces keep the original black lettering readable. The RJL mark is shown in the provenance strip and footer.

`dist/assets/zing-sans-rust.otf` is the supplied **Zing Sans Rust Light Demo Base** font, embedded locally with `@font-face` under the family name **Zing Sans Rust**. The included Fontfabric licence permits web embedding; the licence is retained in `licenses/Fontfabric-Free-Font-License.pdf`. The other fonts in the ZIP are not used.

`dist/assets/ai-face.png` is the user's selected second holographic face, based on the supplied recording. The logo is composited unchanged into the rendered video. The final scene changes to a light background across the entire viewport; there is no separate rectangle or panel behind the logo.

Portal screenshots are unchanged copies of the supplied images and show the site during setup. They are not evidence of live commissioned hardware. The Sentinel and Emergency Guidance images are explicitly labelled illustrative examples. Images are displayed in full at their native proportions; source screenshots remain unchanged.

The supplied detection unit (`detection-unit.webp`) and entrance illustration (`tailgating-example.webp`) retain their original image bytes. The duplicate tailgating upload is included once. The site identifies them as equipment and scenario illustrations; compatibility and installation details are confirmed for each site.

`dist/assets/campus-concept.png` and `dist/assets/venue-concept.png` are generated architectural concept visuals. They are labelled as AI-generated concepts in the site and enlargement captions. Their prompts and tool mode are recorded in `creative/image-prompts.json`; they do not identify actual client installations.

## Verification limits

Source checks and server behaviour can be verified locally. Browser layout, animation, the existing portal destination and live Azure/custom-domain behaviour need verification when a supported browser and deployment connection are available. No website preview has been published to another hosting provider.
