# MagicKeys presentation revision

Reviewed the public product pages on 11 October 2026 (Australia/Sydney):

- Kisi — https://www.getkisi.com/
- Brivo — https://www.brivo.com/
- Salto KS — https://saltosystems.com/en-au/solutions/salto-ks/
- Avigilon Alta — https://www.avigilon.com/access-control/cloud

The common content pattern is an immediate product proposition, clear software and hardware capabilities, applications, and a direct demo or sales path. This is a design interpretation of their public pages, not a claim that MagicKeys has their certifications, integrations, statistics or customer base.

The MagicKeys composition uses the selected blue AI face beside an animated control card based on the supplied portal, then shows the real software before its supporting feature pitch. Bright product chapters alternate with the blue hero and interactive demonstration. Optional CCTV and Emergency Guidance retain their illustrative labels. No competitor copy or brand artwork is used.

Both supplied logos retain their original pixels and alpha transparency. Logo containers have no fill, blur, border, radius or shadow. They are displayed directly on light page surfaces to preserve the original black lettering. The intro reveal also removes the previous white card; the whole scene becomes light before the transparent logo appears.

Zing Sans Rust remains the supplied local font throughout. Hosting stays Azure-only, and the operational portal remains a separate system.

Browser visual QA is unavailable in this environment. Source, link, asset, video encoding, export and interaction checks are used; the browser verification limit is retained in README.md.

The Detect chapter now pairs the supplied detection-unit photograph with the supplied entrance/tailgating illustration. Both are unchanged WebP assets, with the duplicated entrance upload used once. A shared white product surface keeps the original equipment photography legible, while the brand logos remain directly on the page with true alpha transparency. Both new images can be enlarged with the existing accessible image dialog.

The hero cursor demonstration uses the portal’s green OPEN and red CLOSE controls and a single swing gate, matching the supplied control-card language. It is labelled as a simulated preview, supports manual controls and Pause/Replay, stops outside the visible page and skips automatic motion for reduced-motion users. The complete supplied screen/equipment gallery includes the activity record and both emergency confirmation dialogs. All enquiry prompts use team wording.

Two generated architectural concepts illustrate school-campus and shared-venue configurations using the blue/cyan/orange palette. Labels identify them as AI-generated concepts, and proposed site-specific scopes remain grounded in the portal’s gate controls, schedules, bookings and operator roles.

The October image-loading correction makes both downloadable browser copies genuinely self-contained. Visible images and video posters have direct data-URL attributes, so they do not rely on a missing adjacent folder or a JavaScript image bootstrap. Tab and enlargement controls reuse those embedded URLs; MP4 videos are bundled and played through local object URLs. The Azure source keeps ordinary local asset paths.

Every decorative flat gate and faux building has been replaced with a perspective projection of actual solid 3D mesh geometry. Single and double swing leaves pivot about their hinges, sliding gates translate along a rail, and boom arms rotate from their motor housing. Physical dimensions share one coordinate system, with an aspect-aware camera fit. The foyer has glazed sliding doors, a ceiling sensor and proportioned people. All hardware scenes can be rotated with pointer or keyboard input, with static SVG projections of the same geometry as fallbacks.

Supplied screenshot and equipment pixels are preserved, with full images shown at their native aspect ratio. Tight CSS crops have been removed. The seven newly supplied screenshots are diagnostics showing missing images in the previous download; they are used to identify the failure and are not republished as product artwork.
