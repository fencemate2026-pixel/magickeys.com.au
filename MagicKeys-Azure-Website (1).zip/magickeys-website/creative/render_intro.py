"""Render the MagicKeys face assembly and exact logo reveal as a silent MP4."""
from pathlib import Path
import math
import random
import subprocess
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageChops

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'dist/assets'
portrait = '--portrait' in sys.argv
W, H, FPS, SECONDS = (1080, 1920, 30, 8.8) if portrait else (1920, 1080, 30, 8.8)
rng = random.Random(41)
font = ImageFont.truetype(str(ASSETS / 'zing-sans-rust.otf'), 25)
small = ImageFont.truetype(str(ASSETS / 'zing-sans-rust.otf'), 17)

yy, xx = np.mgrid[0:H, 0:W]
halo = np.exp(-((xx - W*.5)**2/(W*.25)**2 + (yy-H*.43)**2/(H*.48)**2))
rgb = np.zeros((H,W,3), dtype=np.uint8)
for i, (base, light) in enumerate([(5,4),(13,34),(24,69)]):
    rgb[:,:,i] = np.clip(base + halo*light,0,255)
background = Image.fromarray(rgb).convert('RGBA')
light_rgb = np.empty((H,W,3), dtype=np.uint8)
for channel, base in enumerate([237,245,250]):
    light_rgb[:,:,channel] = np.clip(base + halo*(5 if channel==0 else 3),0,255)
light_background = Image.fromarray(light_rgb).convert('RGBA')
light_draw = ImageDraw.Draw(light_background)
for radius in [390,570,740]:
    light_draw.ellipse((W/2-radius,H/2-radius*.74,W/2+radius,H/2+radius*.74),outline=(214,230,240,255),width=1)

face = Image.open(ASSETS / 'ai-face.png').convert('RGBA')
face = face.crop(face.getchannel('A').getbbox())
face.thumbnail((907,1344) if portrait else (625,795), Image.Resampling.LANCZOS)
fx, fy = (W-face.width)//2, (H-face.height)//2-60 if portrait else 108
pieces=[]
cols, rows = 6, 8
for y in range(rows):
    for x in range(cols):
        x0,x1=round(x*face.width/cols),round((x+1)*face.width/cols)
        y0,y1=round(y*face.height/rows),round((y+1)*face.height/rows)
        for triangle in [[(0,0),(x1-x0,0),(0,y1-y0)],[(x1-x0,0),(x1-x0,y1-y0),(0,y1-y0)]]:
            piece=face.crop((x0,y0,x1,y1))
            mask=Image.new('L',piece.size)
            ImageDraw.Draw(mask).polygon(triangle,fill=255)
            piece.putalpha(ImageChops.multiply(piece.getchannel('A'),mask))
            if sum(piece.getchannel('A').getdata())<1800: continue
            angle=rng.uniform(0,math.tau)
            pieces.append((piece,fx+x0,fy+y0,math.cos(angle)*rng.uniform(240,620),math.sin(angle)*rng.uniform(170,430)))
rng.shuffle(pieces)

logo=Image.open(ASSETS/'magickeys-logo.png').convert('RGBA')
logo=logo.crop(logo.getchannel('A').getbbox())
logo.thumbnail((884,333) if portrait else (1140,430),Image.Resampling.LANCZOS)

def ease(value):
    value=max(0,min(1,value))
    return 1-(1-value)**3

def opacity(image, amount):
    result=image.copy()
    result.putalpha(image.getchannel('A').point(lambda value:round(value*max(0,min(1,amount)))))
    return result

def render(t):
    frame=background.copy()
    d=ImageDraw.Draw(frame)
    for x in range(80,W,80): d.line((x,0,x,H),fill=(30,83,118,55),width=1)
    for y in range(60,H,80): d.line((0,y,W,y),fill=(30,83,118,55),width=1)
    for radius in [360,414,465]:
        d.ellipse((W/2-radius,H/2-radius*.82,W/2+radius,H/2+radius*.82),outline=(29,113,173,150),width=1)
    for i in range(85):
        px=(i*173.1+t*(7+i%5))%W
        py=(i*113.7-t*(4+i%7))%H
        d.ellipse((px,py,px+2,py+2),fill=(66,168,218,160))
    d.text((80,65),'MAGICKEYS / INTELLIGENT ACCESS',font=small,fill=(103,178,212,255))
    if not portrait: d.text((W-355,65),'RJL COMMERCIAL / MELBOURNE',font=small,fill=(103,178,212,255))
    head=Image.new('RGBA',(W,H))
    if t<5.65:
        for i,(piece,x,y,dx,dy) in enumerate(pieces):
            start=.28+i*(3.65/max(1,len(pieces)-1))
            u=(t-start)/.62
            if u<=0: continue
            progress=ease(u)
            head.alpha_composite(opacity(piece,min(1,u*2)),(round(x+dx*(1-progress)),round(y+dy*(1-progress))))
        if t>4.2:
            hd=ImageDraw.Draw(head)
            scan=fy+((t-4.2)/1.2)*face.height
            if scan<fy+face.height:
                hd.line((fx-35,scan,fx+face.width+35,scan),fill=(123,237,255,170),width=2)
        frame.alpha_composite(opacity(head,1-max(0,(t-5.05)/.6)))
    if t<5.4:
        label='ASSEMBLING INTELLIGENCE' if t<4.2 else 'INTELLIGENT ACCESS. CLEAR CONTROL.'
        d=ImageDraw.Draw(frame)
        d.text((W/2,H-105),label,font=font,fill=(128,222,255,255),anchor='mm')
        count=min(100,round(max(0,t-.28)/4.05*100))
        d.rounded_rectangle((W/2-210,H-74,W/2+210,H-70),radius=2,fill=(31,68,93,255))
        d.rounded_rectangle((W/2-210,H-74,W/2-210+4.2*count,H-70),radius=2,fill=(72,190,247,255))
    if t>5.3:
        u=ease((t-5.3)/.85)
        # The whole scene resolves to a light page; the logo has no panel or fill.
        frame=Image.blend(frame,light_background,u)
        layer=Image.new('RGBA',(W,H))
        ld=ImageDraw.Draw(layer)
        layer.alpha_composite(logo,((W-logo.width)//2,(H-logo.height)//2-5))
        baseline=H/2+logo.height/2+65
        ld.text((W/2,baseline),'SMARTER ACCESS. SAFER SPACES.',font=font,fill=(24,65,95,255),anchor='mm')
        ld.text((W/2,baseline+48),'MAGICKEYS.COM.AU',font=small,fill=(189,83,15,255),anchor='mm')
        frame.alpha_composite(opacity(layer,u))
    return frame.convert('RGB')

output_name='magickeys-intro-mobile.mp4' if portrait else 'magickeys-intro.mp4'
process=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart','-threads','4',str(ASSETS/output_name)],stdin=subprocess.PIPE)
for index in range(round(SECONDS*FPS)):
    process.stdin.write(render(index/FPS).tobytes())
    if index%60==0: print(f'Rendered {index}/{round(SECONDS*FPS)} frames',flush=True)
process.stdin.close()
if process.wait()!=0: raise SystemExit('Video encoder failed')
print('Rendered the 1080p MagicKeys intro.',flush=True)
