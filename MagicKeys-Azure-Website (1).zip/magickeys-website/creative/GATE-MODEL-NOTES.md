# MagicKeys hardware scenes

The marketing page uses `dist/assets/scene3d.js`, a dependency-free solid-mesh renderer. Canvas2D paints depth-sorted, perspective-projected three-dimensional polygon faces. The gate frames, bars, posts, operators and arms have actual thickness; the page is not stretching a screenshot or rotating flat SVG artwork to imitate a gate.

## Source and proportions

The supplied `portal-overview.png` and `portal-gate-response.png` informed the neutral galvanized steel vertical-bar gate appearance, charcoal equipment/display bases, and modest status accents. The models are representative marketing examples, not engineering drawings, a measured site survey, or an assertion that all shown hardware is installed at every client site.

| Scene | Representative visual scale | Movement |
| --- | --- | --- |
| Single swing | 1.2 m opening, 1.8 m leaf height | A 90° rotation around the left vertical hinge axis |
| Double swing | 3.6 m opening, 1.8 m leaf height | Opposite 90° rotations around the two outer vertical hinges |
| Sliding gate | 4.4 m opening, 1.8 m leaf height | A 4.47 m lateral translation along a ground track; posts and operator stay fixed |
| Boom gate | 4.5 m arm, 1.05 m pivot height | An 84.6° rotation at the operator pedestal |
| Foyer | 1.8 m door opening, 2.24 m door height, 2.94 m representative ceiling | Two sliding leaves move in opposite directions; the ceiling detector and reader remain fixed |

The foyer human figures have an ordinary representative height of 1.70 m. The marked footprint indicates a conceptual detection area; it is not a manufacturer's coverage or range specification. An alert shows two figures and orange indicator accents. No live notification or gate command is sent by these scenes.

## Public API

Load the script before mounting canvas scenes. It creates `globalThis.MagicKeys3D`. The script does not access the DOM until `create()` is called.

```js
const scene = MagicKeys3D.create(canvas, {
  kind: 'single', // 'single', 'double', 'sliding', 'boom', or 'foyer'
  interactive: true,
  compact: false
});
scene.setState('open');
scene.setState('closed', {animate: false});
scene.setKind('double');
scene.resetView();
scene.getView();
scene.destroy();
```

`setKind()` retains the requested state and resets the orbit camera. The renderer accepts states `closed`, `open` and `alert`. Gate `alert` leaves the gate closed; foyer `alert` opens the doors to 85% and introduces the second figure.

`buildModel({kind, state, progress})` returns `{meshes, metadata}`. Each mesh contains its identifier, solid vertices, polygon face indices, material, and optional semantic role/group. Metadata includes physical visual dimensions, stationary hinge/pivot coordinates, moving parts and world bounds. `progress` is an optional 0–1 pose override used by the animation and native geometry previews.

`project({kind, state, progress, yaw, pitch, width, height, compact})` returns `{faces, metadata}`. Angles are radians. Each face has `points: [{x,y}]`, `fill`, `stroke`, `lineWidth`, `depth`, `layer`, `id` and `material`. Most faces also include a world-space normal. Faces are already sorted for drawing. Layer 0 is the physical platform, layer 1 is its clipped contact shadows, and layer 2 is the hardware. Metadata includes the camera, viewport, motion envelope and projected bounds. SVG export should convert any CSS `rgba()` colour to an RGB paint plus explicit opacity for older SVG renderers.

## Interaction and fitting

Dragging with a mouse or touch rotates the camera through a full orbit. Arrow keys rotate; `R`, `r`, `Home`, or a double click restore the default view. The containing page should provide a visible instruction and an accessible canvas label. Canvas dimensions come from its CSS size and resize observations; projection maintains the physical aspect ratios at narrow widths.

Swing, sliding and foyer scenes use a stable camera envelope spanning all movement poses. The boom camera follows its changing height, so both its low closed arm and tall raised arm fill the stage appropriately. Every pose remains inside the viewport throughout orbit and resize.

The renderer has no idle animation loop. It renders only on a requested state transition, resize or camera change, and stops animation when the stage or document becomes hidden. Reduced-motion users receive immediate state changes. Pixel density is capped at 2 to bound CPU and memory use on multiple cards.

## Verification and limits

Focused Node tests check solid mesh thickness, the representative opening/height ratios, fixed hinges and correct opposed rotation, constant arm length, sliding translation with stationary equipment, foyer equipment/person scale, complete-frame projection across poses and camera angles, hidden-stage rendering, reduced-motion behavior, and keyboard reset.

Native SVG polygon previews were rendered with the available Inkscape command-line renderer and visually inspected in closed/open states for all five models and the foyer alert state. The previews show framed vertical-bar steel gates, a recognizable tracked sliding gate and operator, a proportionate barrier arm and pedestal, and glazed foyer doors with an overhead detector. This is native asset QA, not a browser layout test. Interactive browser appearance remains subject to the managed Sites environment's browser availability.

Lighting is neutral with restrained blue/cyan, orange and emerald status accents. The renderer uses painter ordering rather than a per-pixel depth buffer; extremely close intersecting transparent objects may exhibit simplified transparency. It is designed for these small bounded hardware scenes, rather than arbitrary imported CAD meshes or photorealistic rendering.
